﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CubeCodingChallenge.TestCases;
using CubeCodingChallenge.Variables;

namespace CubeCodingChallenge
{
    class MainTestSuite
    {
        static void Main(string[] args)
        {
            //TestCase.GenerateToken();

            UtilityMethods.GenerateToken();
            TestCase.GetListOfFiles();
            TestCase.UploadFile();
            TestCase.VerifyUploadedFile();
            TestCase.DeleteSpecificFile();
            TestCase.ShareFile();
            TestCase.VerifySharedFile();
        }
    }
}
